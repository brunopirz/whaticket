#!/bin/bash
#
# Special variables to be used for general purposes.

readonly NC="\033[0m" # reset colors

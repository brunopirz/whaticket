#!/bin/bash
#
# Variables to be used for background styling.

# app variables

jwt_secret=eVD1DxRz729c1Y3U97Y8YscOgtxs/o8Kw6xMLqLrNso
jwt_refresh_secret=P1qTSCzvaeKW0qpAtxJD11Pb9k+8KFsYjCjioUhW1PE

deploy_password=ZXaUHeZ3EKzU=

#mysql_root_password=$(openssl rand -base64 32)

db_pass=387FhYsm0olSm097541HMSdS

db_user=root
db_name=whaticket

deploy_email=deploy@whaticket.com
